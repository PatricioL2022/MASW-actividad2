<?php
/**
 * Created by PhpStorm.
 * User: Patricio Landa ( alandam@student.universidadviu.com )
 * Date: 15/7/2024
 * Time: 22:13
 */

namespace Database\Factories;
use App\Models\agendadetalle;
use Illuminate\Database\Eloquent\Factories\Factory;

class AgendaDetalleFactory extends Factory
{
    protected $model = agendadetalle::class;
    public function definition()
    {
        return [
        ];
    }

}
