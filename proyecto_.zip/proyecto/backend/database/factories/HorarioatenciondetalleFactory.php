<?php
/**
 * Created by PhpStorm.
 * User: Patricio Landa ( alandam@student.universidadviu.com )
 * Date: 15/7/2024
 * Time: 21:09
 */

namespace Database\Factories;

use App\Models\Horarioatenciondetalle;
use Illuminate\Database\Eloquent\Factories\Factory;

class HorarioatenciondetalleFactory extends Factory
{
    protected $model = Horarioatenciondetalle::class;
    public function definition()
    {
        return [
        ];
    }
}
