<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;

class Controller
{
    //
}
