import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-UK7I6BV3.js";
import "./chunk-TGKW4XAL.js";
import "./chunk-B6PMVP6C.js";
import "./chunk-7V37ODQG.js";
import "./chunk-6G3XUBIW.js";
import "./chunk-ZUT4FFKO.js";
import "./chunk-V4OJ3APX.js";
import "./chunk-4J25ECOH.js";
import "./chunk-NFJ5YDRY.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
