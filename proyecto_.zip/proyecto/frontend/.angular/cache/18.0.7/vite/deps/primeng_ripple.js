import {
  Ripple,
  RippleModule
} from "./chunk-7V37ODQG.js";
import "./chunk-6G3XUBIW.js";
import "./chunk-ZUT4FFKO.js";
import "./chunk-V4OJ3APX.js";
import "./chunk-4J25ECOH.js";
import "./chunk-NFJ5YDRY.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
